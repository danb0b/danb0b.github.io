# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 10:38:21 2018

@author: daukes
"""

import matplotlib.pyplot as plt
import numpy

x = numpy.r_[0:10:100j]
y = numpy.sin(x)

plt.plot(x,y)