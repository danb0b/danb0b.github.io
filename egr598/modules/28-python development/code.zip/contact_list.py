# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 10:41:03 2018

@author: daukes
"""

class Contact(object):
    def __init__(self,first_name,last_name,middle_name = '', email = None):
        self.first_name = first_name
        self.last_name = last_name
        self.middle_name = middle_name
        self.email = email or []
        self.full_name = self.default_full_name()
        
    def __str__(self):
        return '(Contact)'+ self.full_name
    def __repr__(self):
        return str(self)
    def default_full_name(self):
        full_name = self.first_name+ ' '+ self.last_name
        return full_name

class JunkClass(object):
    pass

class AddressBook(object):
    def __init__(self,contacts):
        self.contacts = contacts
    def return_sorted_firstname(self,ascending=True):
        new_list = sorted(self.contacts, key=lambda contact: contact.first_name)
        if not ascending:
            new_list = new_list[::-1]
        return new_list
    def add_middle_initial(self,mi):
        for contact in self.contacts:
            contact.middle_initial = mi
        
    
class Vector(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def __str__(self):
        return str(self.x)+','+str(self.y)
    def __repr__(self):
        return str(self)     
    def sum(self,v2):
        return Vector(self.x+v2.x,self.y+v2.y)
    
    def __add__(self,v2):
        return self.sum(v2)
    
#    def __radd__(self,v2):
#        return self.sum(v2)
    
class Coordinate(Vector):
    def plot(self):
        print('I plotted myself')
    
    def sum(self,v2):
        return Vector(self.x+2*v2.x,self.y+2*v2.y)
    def __add__(self,v2):
        return self.sum(v2)
    
def vectorsum(v1,v2):
    return Vector(v1.x+v2.x,v1.y+v2.y)

dan = Contact('Dan','Aukes',email=['danaukes@asu.edu','daukes@asu.edu'])
#dan.full_name = 'custom full name'
nathan = Contact('Nathan','Eastburn')
jason = Contact('Jason','Vaughn')
zz = Contact('Zz','Haggerty')

contacts = [zz,jason,nathan,dan]
#contacts.append()
ab = AddressBook(contacts)

v1 = Vector(1,0)
v2 = Vector(0,1)
c2 = Coordinate(0,1)