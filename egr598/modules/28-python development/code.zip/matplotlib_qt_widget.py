# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 09:42:08 2018

@author: daukes
"""
# -*- coding: utf-8 -*-
"""
Written by Daniel M. Aukes and CONTRIBUTORS
Email: danaukes<at>asu.edu.
Please see LICENSE for full license.
"""
import sys
import PyQt5 as qt
import PyQt5.QtCore as qc
import PyQt5.QtGui as qg
import PyQt5.QtWidgets as qw
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import numpy

class GraphView(qw.QWidget):
    def __init__(self, *args,title=None, show_nav_bar = True,parent = None,**kwargs):
        super(GraphView, self).__init__(*args,**kwargs)


        self.dpi = 100
        self.fig = Figure((5.0, 3.0), dpi = self.dpi, facecolor = (1,1,1), edgecolor = (0,0,0))
        self.axes = self.fig.add_subplot(111)
        if title:
            self.axes.set_title(title)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setParent(self)
        self.toolbar = NavigationToolbar(self.canvas,self)
        self.toolbar.setVisible(show_nav_bar)
        
        self.layout = qw.QVBoxLayout()
        self.layout.addWidget(self.toolbar)
        self.layout.addWidget(self.canvas)
        self.layout.setStretchFactor(self.canvas, 1)
        self.setLayout(self.layout)
        self.canvas.show()



if __name__ == '__main__':

    qapp = qw.QApplication(sys.argv)

    w = GraphView(title = 'My Title',show_nav_bar = True,parent = None)

#    w.axes.autoscale(True)
#    w.axes.clear()
    x = numpy.r_[0:10:100j]
    y = numpy.sin(x)
    w.axes.plot(x,y)
    w.axes.axis('equal')
    w.axes.axis('off')
    
#    w.canvas.draw()
    w.show()
    qapp.exec_()