# -*- coding: utf-8 -*-
"""
Created on Wed Nov 23 07:56:20 2016

@author: daukes
"""

import qt
import qt.QtCore as qc
import qt.QtGui as qg
import matplotlib
import matplotlib.pyplot as plt
plt.ion()
matplotlib.rcParams['backend.qt4']=qt.loaded
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import numpy

spacing = .25

class MatplotlibWidget(qg.QWidget):
    def __init__(self, name='Name', title='Title', graph_title='Graph Title', parent = None):
        super(MatplotlibWidget, self).__init__(parent)

        self.name = name
        self.graph_title = graph_title

        self.dpi = 100
        self.fig = Figure((5.0, 3.0), dpi = self.dpi, facecolor = (1,1,1), edgecolor = (0,0,0))
        self.axes = self.fig.add_subplot(111)
        
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setParent(self)
        self.toolbar = NavigationToolbar(self.canvas,self)
        
        
        self.button1 = qg.QPushButton('Plot1')        
        self.button2 = qg.QPushButton('Plot2')        
        
        layout1 = qg.QHBoxLayout()
        layout1.addWidget(self.button1)
        layout1.addWidget(self.button2)
        
        self.layout = qg.QVBoxLayout()
        self.layout.addWidget(self.toolbar)
        self.layout.addWidget(self.canvas)
        self.layout.setStretchFactor(self.canvas, 1)
        self.layout.addLayout(layout1)
        self.setLayout(self.layout)
        self.canvas.show()
        
        self.button1.clicked.connect(self.plot1)
        self.button2.clicked.connect(self.plot2)

    def clear(self):
        self.axes.clear()
    def plot(self,*args,**kwargs):
        self.axes.plot(*args,**kwargs)
    def draw(self):
        self.canvas.draw()
    def add_patch(self,patch):
        self.axes.add_patch(patch)
    def scatter(self,*args,**kwargs):
        self.axes.scatter(*args,**kwargs)
    def text(self,*args,**kwargs):
        self.axes.text(*args,**kwargs)
    def plot1(self):
        self.axes.cla()
        self.plot([0,1,1,0],[0,0,1,0])
        self.canvas.draw()
    def plot2(self):
        self.axes.cla()
        self.plot([0,1,1,0,0],[0,0,1,1,0])
        self.canvas.draw()

if __name__ == '__main__':

    import sys
    app = qg.QApplication(sys.argv)
    w = MatplotlibWidget(None)
    w.axes.autoscale(True)
#    labelpos = dict((key,value+[-0.1,0]) for key,value in pos.items())

    w.clear()
#    for link,(x,y) in labelpos.items():
#        w.text(x, y,labels[link],**text_style)
#    circlepos = numpy.array([(0,-item) for item in range(len(operations))])
#    w.scatter(circlepos[:,0],circlepos[:,1],**circle_style)        
    w.axes.axis('equal')
    w.axes.axis('off')
    w.show()
    sys.exit(app.exec_())