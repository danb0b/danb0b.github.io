# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 09:38:34 2018

@author: daukes
"""

import serial
import time
import matplotlib.pyplot as plt
import numpy

ser = serial.Serial(port="COM3")
ser.baudrate = 9600
ser.parity=serial.PARITY_NONE
ser.stopbits= serial.STOPBITS_ONE
#ser.timeout=0
ser.xonxoff = True
#ser.rtscts = False
#ser.dsrdtr = False

t=0

bytestring = b''

for ii in range(100):
    bytestring += ser.read_all()
    time.sleep(.1)

string= bytestring.decode('utf-8')
print(string)
ser.close()
lines = string.split('\n')

xyz = []
for line in lines:
    coords = line.split(',')
    if len(coords)==3:
        xyz.append(coords)
xyz = numpy.array(xyz,dtype=float)
xyz2 = xyz[((xyz==0).prod(1)==0).nonzero()[0],:]

plt.plot(xyz2)

