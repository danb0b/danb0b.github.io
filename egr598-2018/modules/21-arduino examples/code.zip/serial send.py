# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 09:38:34 2018

@author: daukes
"""

import serial
import time
from math import sin, pi
frequency = 1
time_divisions = 100
dt = 1/frequency/time_divisions
A = 1
o = 0

ser = serial.Serial(port="COM4")
ser.baudrate = 9600
ser.parity=serial.PARITY_NONE
ser.stopbits= serial.STOPBITS_ONE
#ser.timeout=0
ser.xonxoff = True
#ser.rtscts = False
#ser.dsrdtr = False

t=0

while t<10:
    t+=dt
    y = 90*A*sin(2*pi*frequency*t) +90+o*180
    writestring = '0.0.1.0.{0}\r'.format(int(y))
    writestring = writestring.encode()
#    print(writestring)
    ser.write(writestring)
    time.sleep(dt)
#writestring = '0.0.1.0.{0}\r'.format(int(45))
#writestring = writestring.encode()
#ser.write(writestring)
#time.sleep(1)
ser.close()