# -*- coding: utf-8 -*-
"""
Created on Mon Jan 29 14:14:09 2018

@author: daukes
"""

import foldable_robotics
import foldable_robotics.dxf 
#import ezdxf
import numpy
import matplotlib.pyplot as plt

import shapely.geometry as sg
from foldable_robotics.layer import Layer
from foldable_robotics.laminate import Laminate
import foldable_robotics.manufacturing

filename = 'fivebar1.dxf'

outer = foldable_robotics.dxf.read_lwpolylines(filename,layer='body')
hinges_up = foldable_robotics.dxf.read_lines(filename,layer='hinge up')
hinges_down = foldable_robotics.dxf.read_lines(filename,layer='hinge down')
hinges = hinges_down+hinges_up

cuts = foldable_robotics.dxf.read_lines(filename,layer='cuts')
cuts += foldable_robotics.dxf.read_lwpolylines(filename,layer='cuts')



cuts1 = []
for item in cuts:
    cuts1.append(sg.LineString(item))
cuts2 = Layer(*cuts1)
cuts2<<=.01
cuts2 = cuts2.to_laminate(5)

hinges = numpy.array(hinges)

plt.axis('equal')

#for line in lines:
#    plt.plot(line[:,0],line[:,1],color='red')
 
import foldable_robotics.parts.castellated_hinge1

p = foldable_robotics.parts.castellated_hinge1.generate()
#p.plot()
p = p.scale(1,.1)

p2 = Laminate(*[Layer() for item in range(5)])
for p3,p4 in hinges:
    p2|=p.map_line_stretch((0,0),(1,0),p3,p4)

p2.plot()

polys = [Layer(sg.Polygon(item)) for item in outer]
body = polys.pop(0)
for item in polys:
    body ^= item
#layer = Layer(*polys)
body = body.to_laminate(5)

holes = foldable_robotics.dxf.read_lwpolylines(filename,layer='holes')
points = []
for item in holes:
    for vertex in item:
        points.append(sg.Point(*vertex))
holes_layer = Layer(*points)
holes_layer<<=.1
holes_lam = holes_layer.to_laminate(5)

#lines2 = [sg.LineString(line) for line in lines]
hole,dummy = foldable_robotics.manufacturing.calc_hole(hinges,.15)
hole = hole.to_laminate(5)
hole = foldable_robotics.manufacturing.cleanup(hole,.025,resolution = 4)
body -= hole
body -= p2
body -= cuts2
body-=holes_lam
body.plot()
#
#dwg = ezdxf.readfile(filename)
#modelspace = dwg.modelspace()
#lines = []
#for e in modelspace:
#    if e.dxftype() == 'LINE':
##        red is code 1, gets added to hinge lines
#        lines.append([(e.dxf.start[0],e.dxf.start[1]),(e.dxf.end[0],e.dxf.end[1])])

